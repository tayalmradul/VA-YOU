# sample-contact-us-page

A sample contact us web page made with HTML, vanilla CSS and JS.

Hosted at https://harshkapadia2.github.io/sample-contact-us-page/

The navbar and footer code was taken from my [sample-challenge-page](https://harshkapadia2.github.io/sample-challenges-page/) project.

Input animation was learnt (not copy-pasted) from [Kartik Soneji's](https://www.linkedin.com/in/kartiksoneji/) project.
